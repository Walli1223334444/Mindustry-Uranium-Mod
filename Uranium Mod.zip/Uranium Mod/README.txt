This is my first mod so don't blame me for it being bad. This mod comes with uranium, 
uranium ore, a uranium refinery, a nucluear reactor and a railgun(it has terrible graphics)
To use the railgun in game you'll need the nuclear reactor to have enough electricity for it.
The railgun uses uranium shells as ammo that are produced in the shell factory.
